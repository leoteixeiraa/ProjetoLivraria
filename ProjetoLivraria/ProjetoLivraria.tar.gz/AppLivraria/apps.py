from django.apps import AppConfig


class ApplivrariaConfig(AppConfig):
    name = 'AppLivraria'
